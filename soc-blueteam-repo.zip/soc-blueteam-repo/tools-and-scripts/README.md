# 🛠️ Tools & Scripts

Detection rules, hunting queries, and automation scripts developed and curated for Blue Team operations.

---

## Detection Engineering Philosophy

> *"Detect behaviors, not binaries."* — Based on the Pyramid of Pain

Rules in this repository prioritize high-confidence, low-noise detections targeting:
- **TTPs** (highest value — hardest for attackers to change)
- **Tools** (medium value)
- **Network & Host artifacts** (medium value)
- Avoiding hash-only detections (lowest value — trivial to bypass)

---

## Contents

### 🔷 Sigma Rules (`sigma-rules/`)
Generic detection rules in [Sigma format](https://github.com/SigmaHQ/sigma) — convertible to any SIEM platform.

```bash
# Convert Sigma to Splunk SPL
sigma convert -t splunk -p splunk_windows rule.yml

# Convert Sigma to KQL (Sentinel)
sigma convert -t kusto -p azure_monitor rule.yml

# Convert Sigma to Elastic
sigma convert -t elasticsearch rule.yml
```

### 🔷 KQL Queries (`kql-queries/`)
Microsoft Sentinel and Defender for Endpoint hunting queries in KQL (Kusto Query Language).

Structure:
```
kql-queries/
├── sentinel/
│   ├── threat-hunting/
│   └── scheduled-analytics/
└── defender/
    ├── endpoint/
    └── identity/
```

### 🔷 Splunk SPL (`splunk-spl/`)
Splunk Search Processing Language queries for threat hunting and detection.

### 🔷 Python Tools (`python-tools/`)
Custom automation scripts for:
- IOC enrichment (VirusTotal, Shodan, AbuseIPDB)
- SIEM alert parsing
- Threat feed ingestion
- Report generation

---

## Sigma Rule Template

```yaml
title: Suspicious PowerShell Encoded Command Execution
id: <generate-uuid>
status: experimental
description: |
    Detects execution of PowerShell with base64 encoded commands,
    commonly used for payload delivery and defense evasion.
references:
    - https://attack.mitre.org/techniques/T1059/001/
author: Your Name
date: 2025/01/01
modified: 2025/01/01
tags:
    - attack.execution
    - attack.t1059.001
    - attack.defense_evasion
    - attack.t1027
logsource:
    category: process_creation
    product: windows
detection:
    selection:
        Image|endswith:
            - '\powershell.exe'
            - '\pwsh.exe'
        CommandLine|contains:
            - ' -e '
            - ' -en '
            - ' -enc '
            - ' -EncodedCommand '
    condition: selection
falsepositives:
    - Legitimate administrative scripts using encoded commands
    - Software installers
level: medium
```

---

## KQL Query Template

```kql
// ============================================================
// Title: [Query Title]
// Author: [Your Name]
// Date: YYYY-MM-DD
// MITRE: T[ID] - [Technique Name]
// Description: [What this detects]
// ============================================================
let timeframe = 24h;
DeviceProcessEvents
| where Timestamp > ago(timeframe)
| where FileName in~ ("powershell.exe", "pwsh.exe")
| where ProcessCommandLine has_any ("-enc", "-EncodedCommand", "-e ")
| project Timestamp, DeviceName, AccountName, ProcessCommandLine, InitiatingProcessFileName
| order by Timestamp desc
```
