# Contributing Guidelines

This is a personal knowledge base. Contributions are not open at this time, but issues and discussions are welcome.

## If you find an error

Please open an **Issue** with:
1. The file path containing the error
2. The incorrect content
3. The suggested correction
4. A reference to support the correction (where applicable)

## If you want to suggest content

Open an **Issue** with the label `content-request` describing:
- Topic area
- What you'd like to see covered
- Why it would be valuable

## Code / Rule Contributions

If you'd like to submit a detection rule or script, open a **Pull Request** with:
- Rule in correct format (Sigma, KQL, SPL)
- Description of what it detects
- MITRE ATT&CK mapping
- Testing notes (what you validated it against)
- Known false positives

All contributions must be original work or properly attributed open-source content.

---

> ⚠️ Do not submit any content containing proprietary information, client data, or unreleased vulnerability details.
