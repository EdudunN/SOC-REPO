# ☁️ Cloud Security

Cloud-native security research, hardening guides, detection strategies, and attack scenario analysis across AWS, Azure, GCP, and Kubernetes.

---

## Coverage Matrix

| Topic | AWS | Azure | GCP | Kubernetes |
|-------|-----|-------|-----|------------|
| IAM Hardening | 🚧 | 🚧 | 🚧 | — |
| Storage Security | 🚧 | 🚧 | 🚧 | — |
| Network Controls | 🚧 | 🚧 | 🚧 | 🚧 |
| Logging & Monitoring | 🚧 | 🚧 | 🚧 | 🚧 |
| Threat Detection | 🚧 | 🚧 | 🚧 | 🚧 |
| Secrets Management | 🚧 | 🚧 | 🚧 | 🚧 |
| Container Security | — | — | — | 🚧 |

🚧 = In Progress | ✅ = Complete | — = N/A

---

## Cloud Attack Taxonomy

Based on **MITRE ATT&CK for Cloud** and real-world observations:

### Most Common Initial Access Vectors
1. **Exposed Access Keys** — Hardcoded in repos, CI/CD, containers
2. **Misconfigured S3/Blob Storage** — Public buckets with sensitive data
3. **SSRF → IMDS Abuse** — Stealing cloud credentials via metadata service
4. **Compromised IAM User** — Phishing, credential stuffing
5. **Vulnerable Public-Facing Services** — RCE on EC2/App Service

### Top Cloud-Specific Techniques (MITRE ATT&CK)
| Technique | ID | Platform |
|-----------|-----|----------|
| Cloud Account Discovery | T1087.004 | All |
| Abuse Elevation Control | T1548 | All |
| Transfer Data to Cloud Account | T1537 | All |
| Modify Cloud Compute Configs | T1578 | All |
| Steal Application Access Token | T1528 | All |
| Exfiltration to Cloud Storage | T1567.002 | All |

---

## Key Tools

| Tool | Purpose | Platform |
|------|---------|----------|
| [ScoutSuite](https://github.com/nccgroup/ScoutSuite) | Multi-cloud security auditing | AWS/Azure/GCP |
| [Prowler](https://github.com/prowler-cloud/prowler) | AWS security assessments | AWS |
| [CloudMapper](https://github.com/duo-labs/cloudmapper) | AWS network visualization | AWS |
| [Cartography](https://github.com/lyft/cartography) | Cloud infrastructure mapping | Multi |
| [Pacu](https://github.com/RhinoSecurityLabs/pacu) | AWS exploitation framework (lab) | AWS |
| [Stratus Red Team](https://github.com/DataDog/stratus-red-team) | Cloud attack simulation | Multi |
| [CloudFox](https://github.com/BishopFox/cloudfox) | Cloud situational awareness | Multi |

---

## Recommended Benchmarks & Frameworks

- **CIS AWS Foundations Benchmark**
- **CIS Azure Foundations Benchmark**
- **CIS Google Cloud Platform Benchmark**
- **AWS Well-Architected Security Pillar**
- **NIST SP 800-204 (Microservices Security)**
- **NSA/CISA Kubernetes Hardening Guide**
