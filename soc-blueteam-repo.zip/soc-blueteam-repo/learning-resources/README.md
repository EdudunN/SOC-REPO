# 📚 Learning Resources

Curated references, certifications roadmap, books, research papers, and hands-on lab guides.

---

## Certifications Roadmap

### Blue Team / SOC Track
```
Entry                    Mid-Level                 Senior / Expert
──────────────────────────────────────────────────────────────────
CompTIA Security+   →   CompTIA CySA+        →   GIAC GDET
                    →   BTL1 / BTL2          →   GIAC GCFA
                    →   eJPT (eLearnSecurity) →   GIAC GCFE
                                              →   GIAC GREM
```

### Cloud Security Track
```
Entry                    Mid-Level                 Senior / Expert
──────────────────────────────────────────────────────────────────
AWS Cloud Pract.   →   AWS Security Spec.   →   CCSP
AZ-900             →   AZ-500               →   CCSK
                   →   GCP Security Prof.   →   AWS Security (Pro)
                   →   CCSP Associate       →   CISSP
```

### Threat Intelligence Track
```
Entry                    Mid-Level                 Senior / Expert
──────────────────────────────────────────────────────────────────
CompTIA Security+  →   GCTI (GIAC)          →   GCFE / GREM
                   →   CPTIA                →   CISSP
                   →   Recorded Future Cert →   CISM
```

---

## Essential Reading

### Books
| Title | Author | Focus |
|-------|--------|-------|
| The Practice of Network Security Monitoring | Richard Bejtlich | NSM / SOC |
| Applied Incident Response | Steve Anson | IR |
| Practical Malware Analysis | Sikorski & Honig | Malware |
| The Threat Intelligence Handbook | CrowdStrike | CTI |
| Cloud Security and Privacy | Tim Mather | Cloud |
| Hacking the Cloud | Nick Jones | Cloud Attack/Defense |
| Blue Team Handbook | Don Murdoch | SOC Operations |
| Intelligence-Driven Incident Response | Scott Roberts | CTI + IR |

### Research Papers & Reports
| Title | Source | Year |
|-------|--------|------|
| M-Trends Annual Report | Mandiant | Annual |
| Threat Landscape Report | ENISA | Annual |
| CrowdStrike Global Threat Report | CrowdStrike | Annual |
| Verizon DBIR | Verizon | Annual |
| Cloud Threat Report | Unit 42 | Annual |

---

## Hands-On Labs

### Free Platforms
- **[LetsDefend](https://letsdefend.io/)** — SOC analyst simulation
- **[Blue Team Labs Online](https://blueteamlabs.online/)** — Defensive challenges
- **[CyberDefenders](https://cyberdefenders.org/)** — DFIR challenges
- **[TryHackMe](https://tryhackme.com/)** — Guided rooms (SOC paths)
- **[Hack The Box](https://www.hackthebox.com/)** — Pro labs (Defender tracks)

### Cloud-Specific
- **[CloudGoat](https://github.com/RhinoSecurityLabs/cloudgoat)** — Vulnerable AWS lab
- **[flaws.cloud](http://flaws.cloud)** — AWS attack/defense challenges
- **[flaws2.cloud](http://flaws2.cloud)** — Attacker and defender perspective
- **[AzureGoat](https://github.com/ine-labs/AzureGoat)** — Vulnerable Azure lab
- **[GCP Goat](https://github.com/JOSHUAJEBARAJ/GCP-Goat)** — Vulnerable GCP lab

### Detection Engineering Practice
- **[Sigma Rules Repository](https://github.com/SigmaHQ/sigma)** — Study and contribute
- **[Atomic Red Team](https://github.com/redcanaryco/atomic-red-team)** — Test your detections
- **[Detection Lab](https://github.com/clong/DetectionLab)** — Full lab environment

---

## YouTube Channels
- John Hammond
- The Cyber Mentor
- Gerald Auger (Simply Cyber)
- SANS Institute
- Black Hills Information Security

---

## Communities
- **Discord:** BlueTeam Community, TryHackMe, HackTheBox
- **Reddit:** r/blueteamsec, r/netsec, r/AskNetsec
- **Twitter/X:** Follow #DFIR, #ThreatHunting, #BlueTeam
