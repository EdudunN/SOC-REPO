# ⚙️ SOC Playbooks

Operational playbooks, detection engineering guides, and IR procedures for Security Operations Center workflows.

---

## Playbook Index

### 🔍 Detection Engineering
| Playbook | Platform | Status |
|----------|----------|--------|
| Sigma Rule Development Guide | Multi-platform | ✅ Active |
| KQL Detection Development (Sentinel) | Microsoft Sentinel | ✅ Active |
| SIEM Tuning & False Positive Reduction | Splunk / Sentinel | 🚧 Draft |

### 🚨 Incident Response
| Playbook | Scenario | NIST Phase |
|----------|----------|------------|
| Ransomware IR | Ransomware | Containment → Recovery |
| BEC (Business Email Compromise) | Phishing / Account Takeover | All Phases |
| Cloud Account Compromise | AWS / Azure / GCP | Detection → Recovery |
| Insider Threat | Data Exfiltration | All Phases |
| DDoS Response | Availability Attack | Containment |

### 🩺 Triage
| Playbook | Alert Type | Decision Tree |
|----------|------------|---------------|
| Alert Severity Classification | All | ✅ |
| Endpoint Anomaly Triage | EDR Alert | ✅ |
| Cloud IAM Anomaly Triage | Cloud | 🚧 Draft |

---

## Playbook Template

```markdown
# Playbook: [Scenario Name]

**Version:** 1.0  
**Last Reviewed:** YYYY-MM-DD  
**Owner:** SOC Team  
**Classification:** Internal  

---

## Trigger Conditions
- Alert fires from [source]
- Threshold: [condition]

---

## Severity & Priority Matrix
| Condition | Severity | Response SLA |
|-----------|----------|--------------|
| [Condition A] | Critical | 15 min |
| [Condition B] | High | 1 hour |

---

## Response Steps

### Phase 1: Detection & Analysis
- [ ] Step 1
- [ ] Step 2

### Phase 2: Containment
- [ ] Isolate affected system
- [ ] Block IOCs at perimeter

### Phase 3: Eradication
- [ ] Remove malicious artifacts
- [ ] Patch exploited vulnerability

### Phase 4: Recovery
- [ ] Restore from known-good backup
- [ ] Monitor for reinfection

### Phase 5: Post-Incident
- [ ] Document timeline
- [ ] Update detection rules
- [ ] Brief stakeholders

---

## Escalation Path
Tier 1 → Tier 2 → IR Team Lead → CISO

---

## Evidence Collection Checklist
- [ ] Memory dump
- [ ] Disk image
- [ ] Network logs (pcap)
- [ ] SIEM logs export
- [ ] EDR telemetry

---

## Communication Templates
[Links to pre-approved communication templates]
```
