# 📝 Write-Ups

This directory contains technical write-ups documenting security investigations, threat hunts, malware analysis, and cloud security scenarios.

---

## 📐 Write-Up Template

Each write-up follows this standardized structure for consistency and professional quality.

---

## Subdirectories

| Folder | Description |
|--------|-------------|
| `incidents/` | Post-incident analysis reports (anonymized) |
| `threat-hunting/` | Proactive hunt hypotheses and results |
| `malware-analysis/` | Static and dynamic malware analysis |
| `phishing/` | Email threat and BEC analysis |
| `cloud-security/` | Cloud-specific attack scenario analysis |

---

## 📋 Write-Up Template

```markdown
# [Write-Up Title]

**Date:** YYYY-MM-DD  
**Author:** [Your Name]  
**Category:** [Incident / Threat Hunt / Malware / Phishing / Cloud]  
**Severity:** [Critical / High / Medium / Low]  
**Status:** [Completed / Ongoing / Draft]  

---

## Executive Summary
Brief, non-technical summary of the event and impact.

---

## Technical Environment
- **Platform:** 
- **SIEM:** 
- **Affected Systems:** 
- **Detection Source:** 

---

## Timeline
| Timestamp (UTC) | Event |
|-----------------|-------|
| YYYY-MM-DD HH:MM | Initial alert triggered |

---

## MITRE ATT&CK Mapping
| Tactic | Technique | Sub-Technique | Description |
|--------|-----------|---------------|-------------|
| Initial Access | T1566 | T1566.001 | Spearphishing Attachment |

---

## Investigation

### 1. Initial Triage
...

### 2. Deep Dive Analysis
...

### 3. Pivoting & Correlation
...

---

## Indicators of Compromise (IOCs)
| Type | Value | Confidence | Context |
|------|-------|------------|---------|
| IP | x.x.x.x | High | C2 server |
| Hash (SHA256) | abc123... | High | Malware dropper |
| Domain | evil.com | Medium | Phishing domain |

---

## Detection Opportunities

```sigma
title: [Detection Rule Title]
status: experimental
description: |
    Detects ...
logsource:
    product: windows
    category: process_creation
detection:
    selection:
        CommandLine|contains: 'suspicious_command'
    condition: selection
```

---

## Lessons Learned
- What went well
- What could be improved
- Detection gaps identified

---

## Recommendations
1. Short-term (immediate)
2. Medium-term (30-90 days)
3. Long-term (strategic)

---

## References
- [Reference 1]
- [Reference 2]
```
