# Sample Post — Week 1, Wednesday
**Pillar:** Incident Response / Case Study  
**Type:** Anonymized Scenario

---

## POST CONTENT

🚨 The attacker had been inside the network for 23 days.

The SIEM logged it on Day 2.

Here's what happened — and what changed in our detection program after:

**The Initial Signal (Day 2)**

A scheduled task was created by a non-standard process. Low severity. Auto-closed by a tier-1 analyst after 4 minutes.

The task name? `MicrosoftEdgeUpdateTaskMachineCore`

Legitimate name. But wrong parent process. Wrong user context. Wrong timing.

**The Escalation (Day 23)**

Data staged in a hidden directory. Large outbound transfers. Antivirus disabled on 3 endpoints.

By then, the attacker had:
→ Established persistence (T1053.005 — Scheduled Task)
→ Moved laterally via PsExec (T1021.002)
→ Dumped credentials from LSASS (T1003.001)
→ Staged 40GB of data for exfiltration (T1074.001)

**What we missed:**

The first alert had a confidence score of 40. Our threshold for escalation was 70.

The scoring model hadn't been calibrated in 8 months.

**What we changed:**

✅ Added contextual correlation: scheduled task + unusual parent process = auto-escalate regardless of score

✅ Built a detection rule for "legitimately-named tasks in unexpected contexts"

✅ Implemented weekly detection gap reviews against new MITRE techniques

✅ Reduced alert auto-close SLA from "4 minutes" to "never for process-related alerts without analyst sign-off"

**The Sigma rule that would have caught it on Day 2:**

```yaml
title: Scheduled Task Created by Suspicious Parent Process
tags:
    - attack.persistence
    - attack.t1053.005
detection:
    selection:
        EventID: 4698
        TaskName|contains:
            - 'MicrosoftEdge'
            - 'GoogleUpdate'
            - 'WindowsUpdate'
    filter_legit:
        SubjectUserName|endswith: '$'
    condition: selection and not filter_legit
```

---

Day 2 vs Day 23. The difference was one calibrated rule and one analyst with 4 more minutes.

Every dismissed alert deserves a question: *why am I confident this is benign?*

Not just: *why might this be malicious?*

#IncidentResponse #BlueTeam #SOC #ThreatHunting #MITRE #DetectionEngineering #DFIR #CyberSecurity
