# Sample Post — Week 1, Friday
**Pillar:** Cloud Security  
**Type:** Tool / Tip Spotlight

---

## POST CONTENT

☁️ One misconfiguration. One API call. Full AWS account takeover.

Here's the scenario I use to train every cloud security team — and the 3 controls that would have stopped it at each stage:

**The Attack Chain:**

1. Developer commits AWS access key to a public GitHub repo
2. Attacker runs automated scanner (truffleHog, GitLeaks) — finds it in 4 minutes
3. Attacker calls `sts:GetCallerIdentity` — key is valid
4. Attacker calls `iam:ListAttachedUserPolicies` — key has AdministratorAccess
5. Attacker creates a new IAM user with console access
6. Attacker enables persistence, starts mining crypto on 50 EC2 instances

**Time from key exposure to persistence: 11 minutes.**

**The 3 controls that break this chain:**

**Stage 1 — Prevention (before the commit)**
→ Pre-commit hooks with `detect-secrets` or `git-secrets`
→ GitHub Advanced Security secret scanning (auto-blocks push)

**Stage 2 — Detection (after the commit)**
→ AWS GuardDuty: `UnauthorizedAccess:IAMUser/InstanceCredentialExfiltration`
→ CloudTrail alert on `GetCallerIdentity` from unknown IP ranges

**Stage 3 — Blast radius reduction (assuming compromise)**
→ Least privilege — no access key should have AdministratorAccess
→ SCP (Service Control Policy) limiting IAM user creation to approved regions
→ AWS IAM Access Analyzer continuously validating permissions

**The KQL equivalent for Azure (Sentinel):**

```kql
AzureActivity
| where OperationNameValue == "MICROSOFT.AUTHORIZATION/ROLEASSIGNMENTS/WRITE"
| where ActivityStatusValue == "Success"
| where Caller !in (allowed_service_principals)
| project TimeGenerated, Caller, ResourceGroup, Properties
```

---

Shared credentials don't expire. Stolen credentials don't announce themselves.

The only thing that limits attacker damage is what your controls stop them from doing *after* they get in.

🔗 Full cloud security detection playbook: [GitHub link]

#CloudSecurity #AWS #IAM #BlueTeam #DevSecOps #GuardDuty #MITRE #CyberSecurity #CloudNative
