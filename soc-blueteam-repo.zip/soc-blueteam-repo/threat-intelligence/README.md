# 🕵️ Threat Intelligence

This directory contains Cyber Threat Intelligence (CTI) artifacts including IOC feeds, APT group profiles, and MITRE ATT&CK TTP mappings.

---

## CTI Methodology

All intelligence produced in this repository follows the **Intelligence Cycle**:

```
Direction → Collection → Processing → Analysis → Dissemination → Feedback
```

Intelligence is classified using the **Traffic Light Protocol (TLP)**:

| Label | Sharing |
|-------|---------|
| 🔴 TLP:RED | Not for disclosure (internal only) |
| 🟠 TLP:AMBER | Limited disclosure |
| 🟡 TLP:AMBER+STRICT | Recipients only |
| 🟢 TLP:GREEN | Community sharing |
| ⚪ TLP:CLEAR | Unlimited |

---

## APT Profile Template

```markdown
# APT Profile: [Group Name / Alias]

**Also Known As:** [Other aliases]  
**Origin:** [Suspected nation-state or region]  
**Motivation:** [Espionage / Financial / Hacktivism / Destruction]  
**Active Since:** [Year]  
**Last Observed:** [Date]  
**Targeted Sectors:** [Government, Finance, Energy, etc.]  
**Targeted Regions:** [Geographic focus]  

---

## Overview
Brief description of the threat actor.

---

## TTPs — MITRE ATT&CK
| Tactic | Technique ID | Technique Name | Tool/Evidence |
|--------|-------------|----------------|---------------|

---

## Key Tools & Malware
| Tool | Type | Description |
|------|------|-------------|

---

## Infrastructure
- C2 patterns
- Hosting preferences
- Certificate fingerprints

---

## Historical Campaigns
| Campaign | Year | Target | Summary |
|----------|------|--------|---------|

---

## Detection Opportunities
- Log sources to monitor
- Behavioral indicators
- YARA/SIGMA rules

---

## References & Sources
- [Link]
```

---

## IOC Feed Structure

IOC files follow STIX 2.1 format where possible. CSV format includes:

```
type,value,confidence,tlp,tags,first_seen,last_seen,context
ip,1.2.3.4,80,GREEN,"c2,apt","2025-01-01","2025-01-15","Cobalt Strike C2"
```
