# Changelog

All notable additions and updates to this knowledge base are documented here.

Format: `[YYYY-MM-DD] — Category — Description`

---

## 2025

### March
- `[2025-03-01]` — Repository — Initial repository structure created
- `[2025-03-01]` — LinkedIn — Week 1 posts published (Detection Engineering, IR Case Study, Cloud IAM)

---

<!-- Add new entries at the top of each month section -->
