# Sample Post — Week 1, Monday
**Pillar:** Detection Engineering  
**Type:** Technical Deep Dive

---

## POST CONTENT

🔍 Most SIEM alerts are noise. But the 3% that aren't will cost you everything.

Here's how I approach alert quality — and the framework I use to stop drowning in false positives:

The problem isn't volume. It's signal-to-noise ratio.

A well-tuned SIEM with 100 daily alerts outperforms a noisy one with 10,000 — every time.

Here's the framework I use (based on the Pyramid of Pain):

→ **Level 1 — Hash-based detections:** Easiest for attackers to bypass. Rotate a single byte, new hash. These should be a minority of your rules.

→ **Level 2 — Network indicators:** IP/domain blocks. Better, but still fragile. Attackers rotate infrastructure constantly.

→ **Level 3 — TTPs (Tactics, Techniques, Procedures):** This is where detection becomes durable. Behavioral patterns that attackers CAN'T easily change.

The detection that catches the most:

```kql
// Detects LSASS memory dumping via common tools
DeviceProcessEvents
| where FileName in~ ("procdump.exe", "mimikatz.exe", "lsassy.exe")
    or (FileName == "rundll32.exe" and ProcessCommandLine has "comsvcs.dll")
| where InitiatingProcessFileName !in~ ("svchost.exe", "wmiprvse.exe")
| project Timestamp, DeviceName, AccountName, FileName, ProcessCommandLine
```

Why this works: it detects behavior (credential dumping technique), not a specific file hash.

The result? One rule. Multiple tools covered. Attacker can't trivially bypass it.

---

**Takeaway:** Stop hunting for malware. Start hunting for attacker behavior.

Every sophisticated threat actor uses different tools. They all follow similar patterns.

Build your detection layer around patterns — not artifacts.

🔗 Full KQL query library + Sigma rules: [GitHub link]

#BlueTeam #DetectionEngineering #SOC #KQL #MicrosoftSentinel #ThreatHunting #MITRE #CyberSecurity
